﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Name = "Kicata";
            person.Age = 13;

            Console.WriteLine($"{person.Name} {person.Age}");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonsInfo
{
   public class StartUp
    {
        static void Main(string[] args)
        {


            Person person = new Person("ja", "jaaa", 29, 20213.40m);

            ;

        }
    }
}
